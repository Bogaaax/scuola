package com.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 3000);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connesso al server. Inserisci un'operazione (es. 10 * 5) oppure 'exit' per uscire.");

            while (true) {
                System.out.print("> ");
                String input = scanner.nextLine().trim();

                out.println(input);

                if (input.equalsIgnoreCase("exit")) {
                    break;
                }

                String response = in.readLine();
                System.out.println("Risposta dal server: " + response);
            }

        } catch (IOException e) {
            System.err.println("Errore del client: " + e.getMessage());
        }

        System.out.println("Client terminato.");
    }
}

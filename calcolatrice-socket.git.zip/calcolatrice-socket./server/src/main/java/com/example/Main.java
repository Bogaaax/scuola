package com.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {

    public static void main(String[] args) {
        System.out.println("Server avviato, in ascolto sulla porta 3000...");

        try (ServerSocket serverSocket = new ServerSocket(3000);
             Socket clientSocket = serverSocket.accept();
             BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

            System.out.println("Client connesso: " + clientSocket.getInetAddress());

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.trim().equalsIgnoreCase("exit")) {
                    System.out.println("Il client ha chiuso la connessione.");
                    break;
                }
                String result = evaluate(inputLine.trim());
                out.println(result);
            }

        } catch (IOException e) {
            System.err.println("Errore del server: " + e.getMessage());
        }

        System.out.println("Server terminato.");
    }

    private static String evaluate(String expression) {
        String[] parts = expression.split("\\s+");
        if (parts.length != 3) {
            return "ERR-1:invalid_expression";
        }

        double a, b;
        try {
            a = Double.parseDouble(parts[0]);
            b = Double.parseDouble(parts[2]);
        } catch (NumberFormatException e) {
            return "ERR-1:invalid_number";
        }

        String op = parts[1];
        double result;
        switch (op) {
            case "+" -> result = a + b;
            case "-" -> result = a - b;
            case "*" -> result = a * b;
            case "/" -> {
                if (b == 0) {
                    return "ERR-0:divided_by_zero";
                }
                result = a / b;
            }
            default -> {
                return "ERR-2:unsupported_operator";
            }
        }
        return String.valueOf(result);
    }
}

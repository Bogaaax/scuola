# Calcolatrice Client-Server (Socket TCP)

Due progetti Maven separati che comunicano via socket TCP sulla porta 3000.

## Struttura del repository
```
├── server/   # progetto Maven del server (calcolatrice)
└── client/   # progetto Maven del client
```

## Compilazione
```bash
mvn -q clean package -f server/pom.xml
mvn -q clean package -f client/pom.xml
```

## Avvio
Terminale 1 (server):
```bash
mvn -q exec:java -Dexec.mainClass=com.example.Main -f server/pom.xml
# oppure dopo il package:
java -cp server/target/classes com.example.Main
```

Terminale 2 (client):
```bash
mvn -q exec:java -Dexec.mainClass=com.example.Main -f client/pom.xml
# oppure:
java -cp client/target/classes com.example.Main
```

## Uso
Dal client inserire operazioni nel formato `numero operatore numero`, es.:
```
> 10 * 5
Risposta dal server: 50.0
> 20 / 4
Risposta dal server: 5.0
> 7 + 2
Risposta dal server: 9.0
> 10 / 0
Risposta dal server: ERR-0:divided_by_zero
> exit
```

## Codici di errore
| Codice | Significato |
|---|---|
| `ERR-0:divided_by_zero` | divisione per zero |
| `ERR-1:invalid_expression` | formato non valido (servono esattamente 3 token) |
| `ERR-1:invalid_number` | operando non numerico |
| `ERR-2:unsupported_operator` | operatore non supportato (supportati: + - * /) |
